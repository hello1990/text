package com.asp.springaop;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.springframework.stereotype.Service;
@Service
public class ServiceImpl implements Services {
	
	  public void test(){ 
    	  System.out.println("-----------------我进入Services 方法了-----------------------------------------------");
		  BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();  
	      ThreadPoolExecutor executor = new ThreadPoolExecutor(2, 6, 1, TimeUnit.DAYS, queue);  
	      for (int i = 0; i < 10; i++) {     
	             executor.execute(new Thread(new ThreadPoolTest(), "TestThread".concat(""+i)));     
	             int threadSize = queue.size();  
	             System.out.println("线程队列大小为-->"+threadSize);  
	      }     
	      executor.shutdown();    
	  }

}
