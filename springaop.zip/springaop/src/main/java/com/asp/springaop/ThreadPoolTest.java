package com.asp.springaop;

public class ThreadPoolTest  implements Runnable {

	public void run() {
		  synchronized(this) { 
	            try{
	                System.out.println(Thread.currentThread().getName());
	                Thread.sleep(3000);
	            }catch (InterruptedException e){
	                e.printStackTrace();
	            }
	      } 
		
	}

}
