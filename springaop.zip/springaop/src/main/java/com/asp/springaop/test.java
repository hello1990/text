package com.asp.springaop;

public class test {
	public static void main(String[] args) {
		String str ="2016-12-12 11:42:07";
		String date = "";
		if(str != null && !"".equals(str)){
			for(int i=0;i<str.length();i++){
				if(str.charAt(i)>=48 && str.charAt(i)<=57){
					date+=str.charAt(i);
				}
			}
		}
		System.out.println(date);
	}
}
