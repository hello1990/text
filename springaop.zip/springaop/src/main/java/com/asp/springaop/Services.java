package com.asp.springaop;

public interface Services {
	public abstract void test();
}
