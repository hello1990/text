package com.asp.springaop;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
@Component
@Aspect  
public class Aspects {
	@Pointcut("execution(* com.asp.springaop.Tests.aoptest(..))")
	public void pointcuts() {
	}

	@Before("pointcuts()")
	public void doBefore() {
		// 调用方法执行前
		System.out.println("<------------------doBefore------------------>");
	}

	@After("pointcuts()")
	public void doAfter(JoinPoint jp) {
		System.out.println("<------------------ end ------------------>");
	
		
	}
	@Around("pointcuts()")
	public void aa(ProceedingJoinPoint pjp)  throws Throwable   {
		Map<String,Object> params = new HashMap<String,Object>();
		Object[] args = pjp.getArgs();
		HttpServletRequest request = null;
		Class<?> oclass = null;
		Object obj = null;
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < args.length; i++) {
			if (args[i] instanceof HttpServletRequest) {
				request = (HttpServletRequest) args[i];
				// 改变params 参数
				String startDate = String.valueOf(request.getParameter("startDate"));
				if(startDate != null && !startDate.equals("null")){
					args[i] = sb.append(startDate.replaceAll("-", "")+"000000").toString();
				}
			}else{
				// 实体转换map
				obj = args[i];
				oclass = obj.getClass();
				Field[] field =oclass.getDeclaredFields();
				for (Field field2 : field) {
					field2.setAccessible(true);
					params.put(field2.getName(), field2.get(obj));
				}
				args[i] = params;
			}
		}
		
		pjp.proceed(args);
    }
}
