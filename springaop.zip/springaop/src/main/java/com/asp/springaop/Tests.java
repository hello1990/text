package com.asp.springaop;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import com.token.test.Token;
@Controller

public class Tests {
	
	@Autowired
	Services ser;

	@RequestMapping(value = "show")
	@Token(save=true)
	public ModelAndView show(HttpServletRequest requert){
		System.out.println("redy go index2");
		ModelAndView mv = new ModelAndView();
        mv.setViewName("index2");
        return mv;
	}
	
	
	@RequestMapping(value = "asp")
	@Token(remove=true)
	public void aoptest111(Enitty entity,HttpServletRequest requert,HttpServletResponse response){
		
		System.out.println("eeeeeeeeeeeeeeee");
	}
	
	/*public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext ac = new ClassPathXmlApplicationContext("classpath:application-context.xml");
		Tests t=ac.getBean(Tests.class);
		t.aoptest();
	}*/
}
