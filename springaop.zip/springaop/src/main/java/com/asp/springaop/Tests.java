package com.asp.springaop;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller

public class Tests {
	
	@Autowired
	Services ser;

	@RequestMapping(value = "asp")
	public void aoptest(Enitty entity,HttpServletRequest requert){
		ser.test();
	}
	
	/*public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext ac = new ClassPathXmlApplicationContext("classpath:application-context.xml");
		Tests t=ac.getBean(Tests.class);
		t.aoptest();
	}*/
}
