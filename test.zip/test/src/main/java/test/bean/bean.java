package test.bean;
/** 
 * ����:
 * wyc : 2016��9��14�� ����11:23:15
 * Copyright (c) 2016, All Rights Reserved. 
 */
public class bean {
	private String id;
	private String name;
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}

	
}


