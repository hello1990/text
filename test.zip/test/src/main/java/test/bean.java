package test;
/** 
 * ����:
 * wyc : 2016��9��14�� ����11:23:15
 * Copyright (c) 2016, All Rights Reserved. 
 */
public class bean {
	private String realName;

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}
	
}


