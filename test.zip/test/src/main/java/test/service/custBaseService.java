package test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import test.test;
import test.mapper.CustBaseInfoMapper;
import test.util.DynamicSqlSessionDaoSupport;

/** 
 * ����:
 * wyc : 2016��9��17�� ����5:43:45
 * Copyright (c) 2016, All Rights Reserved. 
 */
@Repository
public class custBaseService  extends DynamicSqlSessionDaoSupport implements BaseDao{
	@Autowired
	CustBaseInfoMapper custDao;
	
	public List<test> queryCustBaseInfo(){
		return custDao.queryCustBaseInfo();
	}
}


