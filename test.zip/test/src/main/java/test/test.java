package test;

import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import test.mapper.CustBaseInfoMapper;
import test.service.custBaseService;
import test.util.DbContextHolder;

@Controller
@RequestMapping("/user")
public class test {
//	@Autowired
//	custBaseService custService;
	
//	 @Resource(name = "propertiesReader")  
//	    private Properties prop;  
	
	  @RequestMapping(value="/tmlData") //,method=RequestMethod.POST
	  @ResponseBody
	  public List<test>  tplData(HttpServletRequest request){ 
		
		/*	System.out.println("&&&&&&&&&&&&&&&&&&:"+prop.get("oracle_key"));
			System.out.println(prop.get("oracle_key"));
		  DbContextHolder.setDbType(DbContextHolder.MYSQL_DATASOURCE);  //��̬�л�
		  List<test> custBaseInfo =  custService.queryCustBaseInfo();	
		  System.out.println("###########:"+custBaseInfo.size());
		  request.setAttribute("custBaseInfo",custBaseInfo);*/
		  return null;  
	  }
	  
}	
