package test.util;

public class DbContextHolder {
	 private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();  
     public static final String ORACLE_DATASOURCE = "oracle";    
     public static final String MYSQL_DATASOURCE = "mysql";    
    /** 
     * 设置当前数据库�? 
     * @param dbType 
     */  
    /* @Resource 
     private DynamicDataSource dds;*/  
    public static void setDbType(String dbType)  
    {  
        contextHolder.set(dbType);  
          
    }  
    /** 
     * 取得当前数据源�? 
     * @return 
     */  
    public static String getDbType()  
    {  
        String str = (String) contextHolder.get();  
     /*   if (null == str || "".equals(str))  
            str = "1";  */
        return str;  
    }  
      
    /** 
     * 清除上下文数�?
     */  
    public static void clearDbType()  
    {  
        contextHolder.remove();  
    }  
    
}


