package test.util;

import java.util.Map;
import java.util.logging.Logger;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;


public class MultipleDataSource extends AbstractRoutingDataSource {
    @Override  
    protected Object determineCurrentLookupKey() {  
        return DbContextHolder.getDbType();    
    }  
  
    @Override  
    public Logger getParentLogger()  {  
        return null;  
    }  
    @Override  
    public void setTargetDataSources(Map targetDataSources) {  
        super.setTargetDataSources(targetDataSources);  
    }  
    
}


