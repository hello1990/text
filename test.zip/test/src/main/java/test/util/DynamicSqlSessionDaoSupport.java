package test.util;
import java.util.Map;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionUtils;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
/** 
 * ����:
 * wyc : 2016��9��17�� ����4:56:58
 * Copyright (c) 2016, All Rights Reserved. 
 */
public class DynamicSqlSessionDaoSupport extends SqlSessionDaoSupport implements ApplicationContextAware  {
	 private ApplicationContext applicationContext;
	    
	    private Map<Object, SqlSessionFactory> targetSqlSessionFactorys;
	    private SqlSessionFactory defaultTargetSqlSessionFactory;
	    private SqlSession sqlSession;
	 
	    @Override
	    public final SqlSession getSqlSession() {
	        SqlSessionFactory targetSqlSessionFactory = targetSqlSessionFactorys.get(DbContextHolder.getDbType());
	        if (targetSqlSessionFactory != null) {
	            setSqlSessionFactory(targetSqlSessionFactory);
	        } else if (defaultTargetSqlSessionFactory != null) {
	            setSqlSessionFactory(defaultTargetSqlSessionFactory);
	            targetSqlSessionFactory = defaultTargetSqlSessionFactory;
	        } else {
	            targetSqlSessionFactory = (SqlSessionFactory) applicationContext.getBean(DbContextHolder.getDbType());
	            setSqlSessionFactory(targetSqlSessionFactory);
	        }
	        this.sqlSession = SqlSessionUtils.getSqlSession(targetSqlSessionFactory);
	        return this.sqlSession;
	    }
	 
	    @Override
	    protected void checkDaoConfig() {
	        //Assert.notNull(getSqlSession(), "Property 'sqlSessionFactory' or 'sqlSessionTemplate' are required");
	    }
	 
	    public void setTargetSqlSessionFactorys(Map<Object, SqlSessionFactory> targetSqlSessionFactorys) {
	        this.targetSqlSessionFactorys = targetSqlSessionFactorys;
	    }
	 
	    public void setDefaultTargetSqlSessionFactory(SqlSessionFactory defaultTargetSqlSessionFactory) {
	        this.defaultTargetSqlSessionFactory = defaultTargetSqlSessionFactory;
	    }
	 
	    @Override
	    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
	        this.applicationContext = applicationContext;
	    }
}


