package test.mapper;

import java.util.List;

import org.springframework.stereotype.Repository;

import test.test;

@Repository
public class CustBaseInfoMapper extends BaseMapper   {
//	public List<test> queryCustBaseInfo();
	public List<test> queryCustBaseInfo(){
		return this.getSqlSessionTemplate().selectList("test.mapper.CustBaseInfoMapper.queryCustBaseInfo");
	}

}
