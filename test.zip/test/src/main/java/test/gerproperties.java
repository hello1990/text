package test;

import java.io.IOException;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.support.PropertiesLoaderUtils;
/** 
 * ����:
 * wyc : 2016��9��21�� ����9:23:16
 * Copyright (c) 2016, All Rights Reserved. 
 */
public class gerproperties {
public static Log log = LogFactory.getLog(gerproperties.class);
	
	private static Properties prop = new Properties();
	
	static {
		try {
			prop.putAll(PropertiesLoaderUtils.loadAllProperties("jdbc.properties"));
		} catch (IOException e) {
			log.error(e);
		}
	}
	
	public static String get(String key) {
		Object obj = prop.get(key);
		if(obj == null) {
			return "";
		}
		return String.valueOf(obj);
	}
}


