package socket;


import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.stereotype.Repository;
//@Service  
//@Transactional 
@Repository(value="myShiro")  
public class MyShiro  extends AuthorizingRealm {

	/*
	 * 
	 *  授权操作，决定那些角色可以使用那些资源 
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection princopal) {
		 //获取登录时输入的用户名  
		String loginName =(String)princopal.fromRealm(getName()).iterator().next();
		 //到数据库查是否有此对象  
		return null;
	}

	/*
	 * 
	 * 认证操作，判断一个请求是否被允许进入系统 
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			AuthenticationToken authenticationToken) throws AuthenticationException {
		  //UsernamePasswordToken对象用来存放提交的登录信息  
        UsernamePasswordToken token=(UsernamePasswordToken) authenticationToken;  
		return null;
	}
	
}
