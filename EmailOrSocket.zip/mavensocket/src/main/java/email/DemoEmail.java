package email;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
@RequestMapping("/hi/")
public class DemoEmail {
	@Autowired
	 private TemplateEmail templateEmail;  
     
	   /* @Resource(name="templateEmail")  
	    public void setTemplateEmail(TemplateEmail templateEmail) {  
	        this.templateEmail = templateEmail;  
	    } */  
	      
	    @RequestMapping(value = "go")
	    public void send(){  
	        Map<String,Object> root = new HashMap<String,Object>();  
	        root.put("username", "ajun");  
	        templateEmail.sendTemplateMail(root, "yongcheng_wu1@126.com","测试","registerUser.ftl");  
	    }  
	    
	    
	    
	    
}
