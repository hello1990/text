xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
        document.open();
        document.write(xmlhttp.responseText);
        document.close();
    }
  }