package mongodb;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class MongodbMain  extends BasicTest {
	@Autowired
	MongoDBBaseDao dao;
	 
	@Test
	public void add(){  
		int i = 1;
		for (int j = 0; j < 2; j++) {
			List<String> list = new ArrayList<String>();
			list.add("hello");
			list.add("mongodb");
			UserEntity user = new UserEntity();
			user.setId("1001"+i);
			user.setContext(list);
			dao.add(user);
			i++;
		}
		
	}  
	
	@Test 
	public void query(){  
		List<UserEntity> list =  dao.findAll(UserEntity.class);
		for (UserEntity userEntity : list) {
			System.out.println(userEntity.toString());
		}
	}  
	
	@Test 
	public void findById(){  
		UserEntity entity =  dao.findById(UserEntity.class,"10011");
		System.out.println(entity.toString());
	} 
	
	
	@Test 
	public void remove(){ 
		UserEntity entity = dao.findById(UserEntity.class,"10011");
	    dao.remove(entity);
	}  
}
