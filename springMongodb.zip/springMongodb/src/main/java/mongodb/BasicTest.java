package mongodb;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
@ContextConfiguration(locations={"classpath:application-context.xml","classpath:spring-mvc.xml"}) 
public class BasicTest extends AbstractJUnit4SpringContextTests{

}
